<?php
$DB_HOST = 'localhost';
$DB_USERNAME = 'root';
$DB_PASSWORD = '12345678';
$DB_NAME = 'cpsc471';

?>
